# Task 6 Report — Password Strength Evaluation

**Name:** [kalash bairagi ]  
**Task:** Create a strong password and evaluate its strength  
**Tool used:** [Passwordmeter.com](https://passwordmeter.com)  

 Objective
To understand what makes a password strong, test multiple passwords using a password strength checker, analyze the results, and derive best practices for secure password creation

 Passwords Tested and Real Results

| # | Password                | Score (%) | Feedback Summary                                      |
|---|-------------------------|-----------|--------------------------------------------------------|
| 1 | `apple`                 | **8%**    | Too short, only lowercase letters, easily guessable.   |
| 2 | `apple123`              | **27%**   | Letters + numbers but still dictionary-based.          |
| 3 | `App!e123`              | **59%**   | Mixed case, number, symbol; still short.               |
| 4 | `A@pp1e_P@ssw0rd!`      | **82%**   | Good length, mixed variety; contains real words.       |
| 5 | `Sun$Moon#Stars2025`    | **90%**   | Long passphrase, mixed characters, numbers, symbols.   |


 Methodology Summary (How Passwordmeter Scores)

Passwordmeter calculates password strength using a scoring formula:

**Additions (increase score):**
- **Length bonus:** `+ (number_of_chars × 4)`  
- **Uppercase letters:** `+ ((length − count_uppercase) × 2)` (if present)  
- **Lowercase letters:** `+ ((length − count_lowercase) × 2)` (if present)  
- **Numbers:** `+ (count_numbers × 4)`  
- **Symbols:** `+ (count_symbols × 6)`  
- **Middle numbers or symbols:** `+ (count_middle × 2)`  
- **Meeting requirements:** `+ (requirements_met × 2)`

**Deductions (reduce score):**
- Only letters or only numbers: `− length`  
- Repeat characters: penalty based on repetition frequency  
- Consecutive uppercase/lowercase/numbers: `− (count × 2)` each  
- Sequential letters/numbers/symbols: `− (count × 3)` each

Scores range **0–100%**. Higher score = stronger password.  
Typical interpretation:  
- 0–20% = Very Weak  
- 21–50% = Weak / Moderate  
- 51–80% = Good  
- 81–100% = Strong / Very Strong


 Analysis & Observations

1. **Length greatly improves strength** — passwords above 12 characters are far harder to brute-force.  
2. **Variety matters** — combining uppercase, lowercase, numbers, and symbols boosts entropy.  
3. **Dictionary words lower score** — even with symbols, real words reduce unpredictability.  
4. **Passphrases are effective** — easy to remember, hard to guess.  
5. **Unique passwords** for every account prevent breach reuse attacks.


 Best Practices

- Use **minimum 12–16 characters**; 20+ for sensitive accounts.  
- Combine different character types (Aa, 0–9, !@#).  
- Avoid names, birthdays, and common words.  
- Enable **Multi-Factor Authentication (MFA)** everywhere possible.  
- Use a **password manager** to generate & store unique passwords.  
- Consider passphrases (e.g., `Blue+River!Orange7`).


 Interview Questions — Answers

1. **What makes a password strong?**  
   A long, unique password with uppercase, lowercase, numbers, and special symbols.

2. **What are common password attacks?**  
   Brute-force, dictionary attack, credential stuffing, rainbow table, phishing.

3. **Why is password length important?**  
   Longer passwords exponentially increase the number of possible combinations.

4. **What is a dictionary attack?**  
   Trying passwords from a list of common words/passwords.

5. **What is multi-factor authentication?**  
   Using two or more verification methods (password + OTP/fingerprint).

6. **How do password managers help?**  
   Generate, store, and autofill unique passwords for each site.

7. **What are passphrases?**  
   Long sequences of random or semi-random words, often with separators.

8. **What are common mistakes in password creation?**  
   Short length, reusing passwords, using personal info, predictable patterns.

---

## 7. Conclusion

Long, unique, complex passwords combined with MFA and a password manager offer the best defense against password attacks. Passphrases balance memorability and strength, making them an excellent choice.

---

**References:**  
- [Passwordmeter.com](https://passwordmeter.com)  
- [Have I Been Pwned](https://haveibeenpwned.com)  
- Bitwarden, 1Password, KeePassXC (Password managers)
