# Task 6 — Create a Strong Password and Evaluate Its Strength

**Objective:** Understand what makes a password strong and test several passwords using an online password strength checker.

**What is included**
- `report.md` — Final report ready to convert to PDF for submission.
- `passwords.txt` — The passwords tested.
- `screenshots/` — Place your password-meter screenshots here (one screenshot per password).
- `task6_submission_instructions.txt` — Quick steps to finalize and submit.

---

## How to complete before submission (quick)
1. Open each password in `passwords.txt` and test it on **https://passwordmeter.com** (or any other checker).
2. Save a screenshot for each password result in `screenshots/` with filenames:
   - `1_simple.png`
   - `2_letters_numbers.png`
   - `3_letters_numbers_symbols.png`
   - `4_mixedcase_symbols.png`
   - `5_passphrase.png`
3. Convert `report.md` to PDF (you can use an online converter or `pandoc`) and include screenshots inside the PDF (or include image links in README).
4. Create a GitHub repo, add these files and the screenshots, and push.
5. Paste the GitHub repo link in your internship submission form.

If you want, reply “Make PDF & ZIP with real screenshots” after you upload screenshots here and I will regenerate the final PDF for you.
